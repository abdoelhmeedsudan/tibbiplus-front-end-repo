import { orderDetails } from "./order";

export const cartItems = orderDetails.products;
