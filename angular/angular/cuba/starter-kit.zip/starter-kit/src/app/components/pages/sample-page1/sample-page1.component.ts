import { Component } from '@angular/core';
import { CommonModule } from '@angular/common';

@Component({
  selector: 'app-sample-page1',
  standalone: true,
  imports: [CommonModule],
  templateUrl: './sample-page1.component.html',
  styleUrl: './sample-page1.component.scss'
})
export class SamplePage1Component {

}
